#include "Dispatcher.h"

Dispatcher::Dispatcher(EventLoop* evLoop) : m_evLoop(evLoop)
{
}

Dispatcher::~Dispatcher()
{
}

int Dispatcher::add()
{
    return 0;
}

int Dispatcher::remove()
{
    return 0;
}

int Dispatcher::modify()
{
    return 0;
}

int Dispatcher::dispatcher(int timeout)
{
    return 0;
}
